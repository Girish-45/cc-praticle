import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Skills } from "@/components/Skills";
import { Projects } from "@/components/Projects";
import { GitHubSection } from "@/components/GitHubSection";
import { Timeline } from "@/components/Timeline";
import { Terminal } from "@/components/Terminal";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { SpotlightCursor } from "@/components/SpotlightCursor";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Girish Jagtap — Full Stack Developer & Creative Engineer" },
      { name: "description", content: "Cinematic developer portfolio of Girish Jagtap — full stack, AI, and immersive web experiences from Pune, India." },
      { property: "og:title", content: "Girish Jagtap — Full Stack Developer" },
      { property: "og:description", content: "Cinematic developer portfolio — full stack, AI, and immersive web experiences." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="relative noise-overlay">
      <SpotlightCursor />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <GitHubSection />
        <Timeline />
        <Terminal />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
