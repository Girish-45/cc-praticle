import { motion, useScroll, useTransform } from "framer-motion";
import { useState } from "react";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#github", label: "GitHub" },
  { href: "#timeline", label: "Journey" },
  { href: "#contact", label: "Contact" },
];

export function Navbar() {
  const { scrollYProgress } = useScroll();
  const width = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
  const [open, setOpen] = useState(false);

  return (
    <>
      <motion.div
        style={{ width }}
        className="fixed top-0 left-0 h-[2px] z-50"
      >
        <div className="h-full w-full" style={{ background: "var(--gradient-neon)" }} />
      </motion.div>
      <motion.nav
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-4 left-1/2 -translate-x-1/2 z-40 px-4 w-[min(96%,1100px)]"
      >
        <div className="glass-strong rounded-full px-5 py-3 flex items-center justify-between">
          <a href="#home" className="font-mono text-sm tracking-tight">
            <span className="text-neon font-bold">girish</span>
            <span className="text-muted-foreground">.dev</span>
          </a>
          <ul className="hidden md:flex gap-1">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="px-3 py-1.5 text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors rounded-full"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="hidden md:inline-flex items-center gap-2 text-xs font-mono px-4 py-2 rounded-full neon-border hover:glow-cyan transition-shadow"
          >
            <span className="w-2 h-2 rounded-full bg-[color:var(--neon-cyan)] animate-pulse" />
            Available
          </a>
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden text-foreground text-xl"
            aria-label="menu"
          >
            ☰
          </button>
        </div>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden mt-2 glass-strong rounded-2xl p-4 flex flex-col gap-2"
          >
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground"
              >
                {l.label}
              </a>
            ))}
          </motion.div>
        )}
      </motion.nav>
    </>
  );
}
