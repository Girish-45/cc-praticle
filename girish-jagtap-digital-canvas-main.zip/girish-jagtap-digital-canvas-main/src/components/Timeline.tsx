import { motion } from "framer-motion";
import { SectionLabel } from "./About";

const items = [
  {
    year: "2024 — Present",
    title: "Software Engineering Student",
    place: "Savitribai Phule Pune University (SPPU)",
    desc: "Studying core CS, DSA, systems, and shipping production-grade web projects on the side.",
  },
  {
    year: "2024",
    title: "Full Stack Web Development",
    place: "Certification",
    desc: "Deep-dived into React, Node.js, MongoDB and modern frontend tooling.",
  },
  {
    year: "Ongoing",
    title: "Learning More",
    place: "Continuous Growth",
    desc: "Exploring new frameworks, system design, and AI — always leveling up.",
  },
];

export function Timeline() {
  return (
    <section id="timeline" className="relative py-32 px-6">
      <div className="max-w-4xl mx-auto">
        <SectionLabel>05 — Journey</SectionLabel>
        <h2 className="text-4xl md:text-5xl font-bold tracking-tight mt-6 mb-16">
          The <span className="text-neon">timeline</span>.
        </h2>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[color:var(--neon-cyan)]/40 to-transparent" />

          <div className="space-y-12">
            {items.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                viewport={{ once: true, margin: "-80px" }}
                className={`relative flex md:items-center md:gap-8 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
              >
                {/* Dot */}
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full" style={{ background: "var(--gradient-neon)", boxShadow: "0 0 20px oklch(0.7 0.22 250 / 0.6)" }} />

                <div className="hidden md:block w-1/2" />

                <div className="ml-12 md:ml-0 md:w-1/2 glass rounded-2xl p-6 hover:glow-cyan transition-shadow">
                  <div className="font-mono text-xs text-[color:var(--neon-cyan)]">{item.year}</div>
                  <h3 className="mt-1 text-lg font-bold">{item.title}</h3>
                  <div className="font-mono text-xs text-muted-foreground mt-1">{item.place}</div>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
