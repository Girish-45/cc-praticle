import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const roles = [
  "Full Stack Developer",
  "Creative Frontend Engineer",
  "AI Enthusiast",
  "Problem Solver",
  "UI/UX Explorer",
];

function MagneticButton({
  children,
  href,
  variant = "primary",
}: {
  children: React.ReactNode;
  href: string;
  variant?: "primary" | "ghost";
}) {
  const [pos, setPos] = useState({ x: 0, y: 0 });
  return (
    <motion.a
      href={href}
      onMouseMove={(e) => {
        const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
        setPos({ x: (e.clientX - r.left - r.width / 2) * 0.25, y: (e.clientY - r.top - r.height / 2) * 0.25 });
      }}
      onMouseLeave={() => setPos({ x: 0, y: 0 })}
      animate={{ x: pos.x, y: pos.y }}
      transition={{ type: "spring", stiffness: 200, damping: 15 }}
      className={`relative inline-flex items-center gap-2 px-6 py-3 rounded-full font-mono text-sm transition-shadow ${
        variant === "primary"
          ? "text-primary-foreground hover:glow"
          : "glass hover:glow-cyan text-foreground"
      }`}
      style={
        variant === "primary"
          ? { background: "var(--gradient-neon)" }
          : undefined
      }
    >
      {children}
    </motion.a>
  );
}

function TypingRole() {
  const [i, setI] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const full = roles[i];
    const timeout = setTimeout(
      () => {
        if (!deleting) {
          setText(full.slice(0, text.length + 1));
          if (text.length + 1 === full.length) setTimeout(() => setDeleting(true), 1400);
        } else {
          setText(full.slice(0, text.length - 1));
          if (text.length - 1 === 0) {
            setDeleting(false);
            setI((p) => (p + 1) % roles.length);
          }
        }
      },
      deleting ? 35 : 70,
    );
    return () => clearTimeout(timeout);
  }, [text, deleting, i]);

  return (
    <span className="text-neon">
      {text}
      <span className="caret text-[color:var(--neon-cyan)]">|</span>
    </span>
  );
}

function FloatingTechIcon({
  label,
  x,
  y,
  delay,
}: {
  label: string;
  x: string;
  y: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.8 }}
      style={{ left: x, top: y }}
      className="absolute hidden md:flex"
    >
      <div className="animate-float glass rounded-2xl px-3 py-2 font-mono text-xs text-muted-foreground" style={{ animationDelay: `${delay}s` }}>
        {label}
      </div>
    </motion.div>
  );
}

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
      {/* Animated grid */}
      <div className="absolute inset-0 grid-bg" />
      {/* Aurora */}
      <div className="absolute inset-0 aurora-bg animate-aurora" />

      {/* Floating tech labels */}
      <FloatingTechIcon label="< React />" x="8%" y="22%" delay={0.8} />
      <FloatingTechIcon label="{ TypeScript }" x="84%" y="28%" delay={1.0} />
      <FloatingTechIcon label="Node.js" x="12%" y="68%" delay={1.2} />
      <FloatingTechIcon label="MongoDB" x="82%" y="72%" delay={1.4} />
      <FloatingTechIcon label="Tailwind" x="6%" y="45%" delay={1.6} />
      <FloatingTechIcon label="GSAP" x="88%" y="50%" delay={1.8} />

      <div className="relative z-10 text-center px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 mb-8 font-mono text-xs text-muted-foreground"
        >
          <span className="w-2 h-2 rounded-full bg-[color:var(--neon-cyan)] animate-pulse" />
          Crafting digital experiences from Pune, India
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.95]"
        >
          Hi, I'm <span className="text-neon">Girish</span>
          <br />
          <span className="text-foreground">Jagtap.</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="mt-6 text-xl md:text-2xl font-mono h-8"
        >
          <TypingRole />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="mt-6 text-muted-foreground max-w-xl mx-auto"
        >
          Building immersive, cinematic web experiences at the intersection of
          design, motion, and intelligent systems.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <MagneticButton href="#projects">Explore Work →</MagneticButton>
          <MagneticButton href="https://github.com/Girish-45" variant="ghost">
            GitHub
          </MagneticButton>
          <MagneticButton href="#contact" variant="ghost">
            Contact Me
          </MagneticButton>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          className="absolute bottom-6 left-1/2 -translate-x-1/2 font-mono text-xs text-muted-foreground"
        >
          <div className="flex flex-col items-center gap-2">
            <span>scroll</span>
            <div className="w-px h-10 bg-gradient-to-b from-[color:var(--neon-cyan)] to-transparent" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
