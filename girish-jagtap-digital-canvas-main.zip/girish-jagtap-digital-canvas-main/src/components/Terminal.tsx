import { motion } from "framer-motion";

const lines = [
  { p: "$ whoami", c: "text-muted-foreground" },
  { p: "girish_jagtap", c: "text-[color:var(--neon-cyan)]" },
  { p: "$ cat about.txt", c: "text-muted-foreground" },
  { p: "→ Full Stack Developer · AI Enthusiast · Pune, India", c: "text-foreground" },
  { p: "$ ls ./skills", c: "text-muted-foreground" },
  { p: "react/  node/  java/  cpp/  mongo/  mysql/  tailwind/", c: "text-foreground" },
  { p: "$ ./run portfolio.dev", c: "text-muted-foreground" },
  { p: "✓ ready · serving cinematic experience on :3000", c: "text-[color:var(--neon-cyan)]" },
];

export function Terminal() {
  return (
    <section className="relative py-20 px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className="max-w-3xl mx-auto glass-strong rounded-2xl overflow-hidden neon-border"
      >
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border/50">
          <span className="w-3 h-3 rounded-full bg-red-500/70" />
          <span className="w-3 h-3 rounded-full bg-yellow-500/70" />
          <span className="w-3 h-3 rounded-full bg-green-500/70" />
          <span className="ml-3 font-mono text-xs text-muted-foreground">~/girish — zsh</span>
        </div>
        <div className="p-6 font-mono text-sm space-y-1.5">
          {lines.map((l, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.15 }}
              viewport={{ once: true }}
              className={l.c}
            >
              {l.p}
            </motion.div>
          ))}
          <div className="flex items-center gap-2 text-[color:var(--neon-cyan)]">
            <span>$</span>
            <span className="caret">▌</span>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
