import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { SectionLabel } from "./About";

const USERNAME = "Girish-45";

type User = {
  public_repos: number;
  followers: number;
  following: number;
  avatar_url: string;
  bio: string | null;
  name: string | null;
  html_url: string;
};

type Repo = {
  id: number;
  name: string;
  description: string | null;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  html_url: string;
  updated_at: string;
};

function TiltRepoCard({ repo, i }: { repo: Repo; i: number }) {
  return (
    <motion.a
      href={repo.html_url}
      target="_blank"
      rel="noreferrer"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: i * 0.06 }}
      viewport={{ once: true }}
      whileHover={{ rotateX: -4, rotateY: 4, y: -4 }}
      style={{ transformStyle: "preserve-3d" }}
      className="group relative glass rounded-2xl p-5 block hover:glow transition-shadow"
    >
      <div className="flex items-center gap-2 font-mono text-xs text-muted-foreground mb-2">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8Z"/></svg>
        repo
      </div>
      <h4 className="text-base font-semibold group-hover:text-neon transition-colors">
        {repo.name}
      </h4>
      <p className="mt-2 text-xs text-muted-foreground line-clamp-2 min-h-[2rem]">
        {repo.description || "No description provided."}
      </p>
      <div className="mt-4 flex items-center gap-4 font-mono text-[10px] text-muted-foreground">
        {repo.language && (
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[color:var(--neon-cyan)]" />
            {repo.language}
          </span>
        )}
        <span>★ {repo.stargazers_count}</span>
        <span>⑂ {repo.forks_count}</span>
      </div>
    </motion.a>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="glass rounded-2xl p-5 text-center hover:glow-cyan transition-shadow">
      <div className="text-3xl font-bold text-neon">{value}</div>
      <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mt-1">{label}</div>
    </div>
  );
}

export function GitHubSection() {
  const [user, setUser] = useState<User | null>(null);
  const [repos, setRepos] = useState<Repo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [u, r] = await Promise.all([
          fetch(`https://api.github.com/users/${USERNAME}`).then((res) => res.ok ? res.json() : null),
          fetch(`https://api.github.com/users/${USERNAME}/repos?sort=updated&per_page=100`).then((res) => res.ok ? res.json() : []),
        ]);
        if (cancelled) return;
        setUser(u);
        const sorted = Array.isArray(r) ? r.sort((a: Repo, b: Repo) => b.stargazers_count - a.stargazers_count).slice(0, 6) : [];
        setRepos(sorted);
      } catch {
        // silent
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <section id="github" className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionLabel>04 — GitHub</SectionLabel>
        <div className="flex flex-wrap items-end justify-between gap-4 mt-6 mb-12">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            Building <span className="text-neon">in public</span>.
          </h2>
          <a
            href={`https://github.com/${USERNAME}`}
            target="_blank"
            rel="noreferrer"
            className="text-xs font-mono px-4 py-2 rounded-full neon-border hover:glow-cyan transition-shadow"
          >
            @{USERNAME} →
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          <StatCard label="Public Repos" value={user?.public_repos ?? "—"} />
          <StatCard label="Followers" value={user?.followers ?? "—"} />
          <StatCard label="Following" value={user?.following ?? "—"} />
          <StatCard label="Status" value="Active" />
        </div>

        {/* Contribution graph (GitHub readme stats) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true }}
          className="glass-strong rounded-3xl p-6 mb-10 overflow-hidden"
        >
          <div className="font-mono text-xs text-muted-foreground mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[color:var(--neon-cyan)] animate-pulse" />
            contribution_graph.svg
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <img
              src={`https://github-readme-stats.vercel.app/api?username=${USERNAME}&show_icons=true&theme=transparent&hide_border=true&title_color=8ad8ff&icon_color=b46bff&text_color=cfd6e4&hide=issues`}
              alt="GitHub stats"
              className="w-full"
              loading="lazy"
            />
            <img
              src={`https://github-readme-stats.vercel.app/api/top-langs/?username=${USERNAME}&layout=compact&theme=transparent&hide_border=true&title_color=8ad8ff&text_color=cfd6e4`}
              alt="Top languages"
              className="w-full"
              loading="lazy"
            />
          </div>
          <img
            src={`https://ghchart.rshah.org/8ad8ff/${USERNAME}`}
            alt="Contribution graph"
            className="w-full mt-4 rounded-lg"
            loading="lazy"
          />
        </motion.div>

        {/* Pinned / Top repos */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="glass rounded-2xl p-5 h-40 animate-pulse" />
              ))
            : repos.map((repo, i) => <TiltRepoCard key={repo.id} repo={repo} i={i} />)}
        </div>
      </div>
    </section>
  );
}
