import { motion } from "framer-motion";
import { useState } from "react";
import { SectionLabel } from "./About";

const socials = [
  { label: "GitHub", href: "https://github.com/Girish-45" },
  { label: "LinkedIn", href: "#" },
  { label: "Instagram", href: "#" },
  { label: "Email", href: "mailto:girish@example.com" },
];

export function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative py-32 px-6">
      <div className="absolute inset-0 aurora-bg opacity-60 animate-aurora pointer-events-none" />
      <div className="relative max-w-5xl mx-auto">
        <SectionLabel>06 — Contact</SectionLabel>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-6 text-4xl md:text-6xl font-bold tracking-tight max-w-3xl"
        >
          Let's build something <span className="text-neon">amazing</span> together.
        </motion.h2>
        <p className="mt-4 text-muted-foreground max-w-xl">
          Have a project in mind, an opportunity, or just want to talk shop?
          The inbox is always open.
        </p>

        <div className="grid md:grid-cols-5 gap-8 mt-12">
          <motion.form
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
              setTimeout(() => setSent(false), 4000);
            }}
            className="md:col-span-3 glass-strong rounded-3xl p-8 space-y-5"
          >
            <div className="grid md:grid-cols-2 gap-4">
              <Field label="Name" id="name" placeholder="John Doe" />
              <Field label="Email" id="email" type="email" placeholder="you@domain.com" />
            </div>
            <Field label="Subject" id="subject" placeholder="Let's collaborate" />
            <div>
              <label htmlFor="msg" className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Message</label>
              <textarea
                id="msg"
                rows={5}
                required
                placeholder="Tell me about your idea..."
                className="mt-2 w-full bg-input/40 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[color:var(--neon-cyan)] focus:glow-cyan transition-all"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl font-mono text-sm font-semibold transition-shadow hover:glow"
              style={{ background: "var(--gradient-neon)", color: "var(--primary-foreground)" }}
            >
              {sent ? "✓ Message Sent" : "Send Message →"}
            </button>
          </motion.form>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            viewport={{ once: true }}
            className="md:col-span-2 space-y-3"
          >
            {socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                className="group glass rounded-2xl p-5 flex items-center justify-between hover:glow-cyan transition-shadow"
              >
                <span className="font-semibold">{s.label}</span>
                <span className="font-mono text-xs text-muted-foreground group-hover:text-[color:var(--neon-cyan)] transition-colors">→</span>
              </a>
            ))}
            <div className="glass rounded-2xl p-5">
              <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Based in</div>
              <div className="mt-1 text-lg">Pune, India 🇮🇳</div>
              <div className="font-mono text-xs text-[color:var(--neon-cyan)] mt-1">UTC +05:30 · Available worldwide</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  id,
  type = "text",
  placeholder,
}: {
  label: string;
  id: string;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        id={id}
        type={type}
        required
        placeholder={placeholder}
        className="mt-2 w-full bg-input/40 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[color:var(--neon-cyan)] focus:glow-cyan transition-all"
      />
    </div>
  );
}
