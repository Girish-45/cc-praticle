import { motion } from "framer-motion";

const stats = [
  { label: "Projects Completed", value: "25+" },
  { label: "GitHub Contributions", value: "500+" },
  { label: "Technologies", value: "15+" },
  { label: "Certifications", value: "8" },
];

export function About() {
  return (
    <section id="about" className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionLabel>01 — About</SectionLabel>

        <div className="grid md:grid-cols-2 gap-16 items-center mt-8">
          {/* Profile glass card */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="relative mx-auto w-full max-w-sm aspect-[4/5]"
          >
            <div className="absolute -inset-1 rounded-3xl opacity-60 blur-2xl animate-glow" style={{ background: "var(--gradient-neon)" }} />
            <div className="relative w-full h-full rounded-3xl overflow-hidden neon-border glass-strong">
              <div className="absolute inset-0 grid-bg opacity-40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-[8rem] font-bold text-neon leading-none">GJ</div>
                  <div className="font-mono text-xs text-muted-foreground mt-2">
                    girish.jagtap.exe
                  </div>
                </div>
              </div>
              <div className="absolute bottom-4 left-4 right-4 glass rounded-xl px-3 py-2 font-mono text-[10px] text-muted-foreground flex justify-between">
                <span>{`> status: building`}</span>
                <span className="text-[color:var(--neon-cyan)]">● online</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              A developer obsessed with <span className="text-neon">craft</span>.
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              Passionate developer who enjoys building modern web experiences,
              exploring AI, and solving real-world problems through code. I care
              deeply about visually immersive interfaces, smooth interactions,
              and code that feels as good as it looks.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Currently studying Software Engineering at SPPU — shipping
              projects, breaking things, and learning relentlessly.
            </p>

            <div className="grid grid-cols-2 gap-3 mt-10">
              {stats.map((s, i) => (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="glass rounded-2xl p-4 hover:glow-cyan transition-shadow"
                >
                  <div className="text-3xl font-bold text-neon">{s.value}</div>
                  <div className="text-xs text-muted-foreground font-mono mt-1">
                    {s.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="font-mono text-xs uppercase tracking-[0.3em] text-[color:var(--neon-cyan)] flex items-center gap-3"
    >
      <span className="w-8 h-px bg-[color:var(--neon-cyan)]" />
      {children}
    </motion.div>
  );
}
