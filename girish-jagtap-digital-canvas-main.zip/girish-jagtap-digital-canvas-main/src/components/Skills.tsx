import { motion } from "framer-motion";
import { SectionLabel } from "./About";

const skills = [
  { name: "HTML", level: 95 },
  { name: "CSS", level: 92 },
  { name: "JavaScript", level: 90 },
  { name: "React", level: 88 },
  { name: "Tailwind CSS", level: 92 },
  { name: "Node.js", level: 80 },
  { name: "Java", level: 82 },
  { name: "C++", level: 78 },
  { name: "MongoDB", level: 75 },
  { name: "MySQL", level: 80 },
  { name: "Git & GitHub", level: 88 },
];

const marquee = [...skills, ...skills];

function TiltCard({ name, level, i }: { name: string; level: number; i: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: i * 0.04 }}
      viewport={{ once: true, margin: "-50px" }}
      whileHover={{ rotateX: -6, rotateY: 6, scale: 1.03 }}
      style={{ transformStyle: "preserve-3d" }}
      className="group relative glass rounded-2xl p-5 cursor-default"
    >
      <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: "var(--gradient-neon)", filter: "blur(20px)", zIndex: -1 }} />
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-sm">{name}</span>
        <span className="font-mono text-xs text-muted-foreground">{level}%</span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${level}%` }}
          transition={{ duration: 1.2, delay: 0.2 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
          viewport={{ once: true }}
          className="h-full rounded-full"
          style={{ background: "var(--gradient-neon)" }}
        />
      </div>
    </motion.div>
  );
}

export function Skills() {
  return (
    <section id="skills" className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionLabel>02 — Stack</SectionLabel>
        <div className="flex flex-wrap items-end justify-between gap-4 mt-6 mb-12">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            Tools I <span className="text-neon">wield</span>.
          </h2>
          <p className="text-muted-foreground max-w-md">
            From low-level systems to high-level interfaces — a curated arsenal
            for building things that feel inevitable.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {skills.map((s, i) => (
            <TiltCard key={s.name} {...s} i={i} />
          ))}
        </div>
      </div>

      {/* Infinite marquee */}
      <div className="relative mt-20 overflow-hidden py-8 border-y border-border/50">
        <div className="flex gap-12 animate-marquee whitespace-nowrap font-mono text-3xl md:text-5xl font-bold">
          {marquee.map((s, i) => (
            <span key={i} className="flex items-center gap-12">
              <span className={i % 3 === 0 ? "text-neon" : "text-muted-foreground/40"}>
                {s.name}
              </span>
              <span className="text-[color:var(--neon-cyan)]">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
