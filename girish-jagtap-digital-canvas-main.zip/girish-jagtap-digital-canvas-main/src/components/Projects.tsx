import { motion } from "framer-motion";
import { SectionLabel } from "./About";

const projects = [
  {
    title: "AI Chatbot",
    description: "Conversational AI assistant powered by LLMs with streaming responses, memory, and multi-turn context handling.",
    tech: ["React", "Node.js", "OpenAI", "WebSockets"],
    gradient: "linear-gradient(135deg, oklch(0.55 0.25 280), oklch(0.7 0.2 200))",
  },
  {
    title: "Portfolio Website",
    description: "Cinematic developer portfolio with custom motion design, glassmorphism, and interactive 3D effects.",
    tech: ["React", "Framer Motion", "Tailwind"],
    gradient: "linear-gradient(135deg, oklch(0.7 0.2 200), oklch(0.65 0.27 300))",
  },
];

function ProjectCard({ p, i }: { p: typeof projects[0]; i: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: (i % 3) * 0.1 }}
      viewport={{ once: true, margin: "-80px" }}
      whileHover={{ y: -8 }}
      className="group relative rounded-3xl overflow-hidden glass-strong"
    >
      {/* Preview */}
      <div className="relative aspect-[16/10] overflow-hidden">
        <div className="absolute inset-0" style={{ background: p.gradient }} />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <motion.div
          className="absolute inset-0 flex items-center justify-center font-mono text-6xl font-bold opacity-20 group-hover:opacity-40 transition-opacity"
        >
          {String(i + 1).padStart(2, "0")}
        </motion.div>
        <div className="absolute top-4 left-4 glass rounded-full px-3 py-1 font-mono text-[10px] text-muted-foreground">
          /// project_{i + 1}
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold tracking-tight group-hover:text-neon transition-colors">
          {p.title}
        </h3>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
          {p.description}
        </p>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {p.tech.map((t) => (
            <span key={t} className="font-mono text-[10px] px-2 py-1 rounded-full bg-muted text-muted-foreground">
              {t}
            </span>
          ))}
        </div>
        <div className="mt-5 flex gap-2">
          <a href="https://github.com/Girish-45" target="_blank" rel="noreferrer" className="text-xs font-mono px-3 py-1.5 rounded-full glass hover:glow-cyan transition-shadow">
            GitHub →
          </a>
          <a href="#" className="text-xs font-mono px-3 py-1.5 rounded-full" style={{ background: "var(--gradient-neon)", color: "var(--primary-foreground)" }}>
            Live Demo
          </a>
        </div>
      </div>
    </motion.article>
  );
}

export function Projects() {
  return (
    <section id="projects" className="relative py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionLabel>03 — Selected Work</SectionLabel>
        <div className="flex flex-wrap items-end justify-between gap-4 mt-6 mb-12">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            Things I've <span className="text-neon">built</span>.
          </h2>
          <p className="text-muted-foreground max-w-md">
            A few experiments and shipped products — each one taught me
            something I couldn't have learned any other way.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((p, i) => (
            <ProjectCard key={p.title} p={p} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
