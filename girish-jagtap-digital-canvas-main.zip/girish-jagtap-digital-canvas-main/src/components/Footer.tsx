export function Footer() {
  return (
    <footer className="relative px-6 py-12 border-t border-border/40">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-xs text-muted-foreground">
        <div>
          © {new Date().getFullYear()} <span className="text-neon">girish.dev</span> — Crafted with obsession.
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[color:var(--neon-cyan)] animate-pulse" />
          all systems operational
        </div>
      </div>
    </footer>
  );
}
